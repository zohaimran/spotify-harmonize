
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality, Type } from "@google/genai";

/**
 * ==========================================
 * TYPES & INTERFACES
 * ==========================================
 */

interface BandMember {
  id: string;
  role: string;
  personality: string;
  strength: string;
  clashPoint: string;
  icon: string;
}

interface LeadershipInsight {
  score: number;
  archetype: string;
  feedback: string;
  actionableAdvice: string;
  musicalStyle: string;
}

enum AppStep {
  INTRO = 'INTRO',
  SQUAD = 'SQUAD',
  SIMULATION = 'SIMULATION',
  RESULT = 'RESULT',
  WRAPPED = 'WRAPPED',
  LOADING_BSIDE = 'LOADING_BSIDE',
  TEASER = 'TEASER'
}

/**
 * ==========================================
 * CONSTANTS
 * ==========================================
 */

const SPOTIFY_GREEN = '#1DB954';

const BAND_MEMBERS: BandMember[] = [
  {
    id: '1',
    role: 'Product Frontman',
    personality: 'Visionary, High-energy, data-obsessed but gut-driven',
    strength: 'User Impact & Vision',
    clashPoint: 'Pushes for "one more thing" before launch',
    icon: '🎤'
  },
  {
    id: '2',
    role: 'Infrastructure Maestro',
    personality: 'Pragmatic, Detail-oriented, focused on uptime and scalability',
    strength: 'Stability & System Harmony',
    clashPoint: 'Resistant to last-minute scope creep',
    icon: '🥁'
  },
  {
    id: '3',
    role: 'Growth Producer',
    personality: 'Strategic, analytical, bridge between tech and the listener',
    strength: 'Market Resonance',
    clashPoint: 'Prioritizes buzz over technical debt',
    icon: '🎚️'
  }
];

const Icons = {
  Play: () => <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M7 6v12l10-6z" /></svg>,
  Pause: () => <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>,
  ArrowRight: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>,
  SkipBack: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/></svg>,
  SkipForward: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M6 18l8.5-6L6 6zm9-12h2v12h-2z"/></svg>
};

/**
 * ==========================================
 * AUDIO UTILITIES
 * ==========================================
 */

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

/**
 * ==========================================
 * GEMINI AI SERVICES
 * ==========================================
 */

const analyzeLeadershipResponse = async (userInput: string): Promise<LeadershipInsight> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `
    Role: Senior Leadership Coach at Spotify.
    Scenario: The "Bandleader" has chosen a specific approach to resolve a crisis.
    Chosen Approach: "${userInput}"
    Task: Analyze this decision through Spotify's values for 2026 (Courage, Collaboration, Passion).
    Return JSON:
    {
      "score": number (0-100),
      "archetype": "string (Creative title)",
      "feedback": "string (Short feedback)",
      "actionableAdvice": "string (Tip for Spotify 2026)",
      "musicalStyle": "string (Musical genre)"
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            archetype: { type: Type.STRING },
            feedback: { type: Type.STRING },
            actionableAdvice: { type: Type.STRING },
            musicalStyle: { type: Type.STRING }
          },
          required: ["score", "archetype", "feedback", "actionableAdvice", "musicalStyle"]
        }
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    return {
      score: 88,
      archetype: "The Harmony Maestro",
      feedback: "Balanced and rhythmic leadership observed in your choices.",
      actionableAdvice: "Continue to sync with your squad leads before major drops.",
      musicalStyle: "Electronic Fusion"
    };
  }
};

const generateWelcomeAudio = async (): Promise<AudioBuffer | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const script = "Welcome to Harmonize! Your 2026 year in leadership remixed. You’ll see your top strengths, growth moments and the habits that shaped your impact. Click to enter the studio.";
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: script }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      return await decodeAudioData(decode(base64Audio), audioCtx, 24000, 1);
    }
  } catch (e) {
    console.error("TTS Error:", e);
  }
  return null;
};

/**
 * ==========================================
 * SUB-COMPONENTS
 * ==========================================
 */

const WelcomePlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const audioCtxRef = useRef<AudioContext | null>(null);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);
  const startTimeRef = useRef<number>(0);
  const pauseTimeRef = useRef<number>(0);
  const duration = 12; // Static duration estimate
  const progressInterval = useRef<number | null>(null);

  useEffect(() => {
    return () => stopPlayback();
  }, []);

  const stopPlayback = () => {
    if (sourceRef.current) {
      try { sourceRef.current.stop(); } catch(e) {}
      sourceRef.current = null;
    }
    if (progressInterval.current) clearInterval(progressInterval.current);
  };

  const togglePlayback = async () => {
    if (!audioBuffer) {
      setIsLoading(true);
      const buffer = await generateWelcomeAudio();
      setAudioBuffer(buffer);
      setIsLoading(buffer === null ? false : true); // stay loading if failed
      if (buffer) {
        setIsLoading(false);
        playFrom(buffer, 0);
      }
      return;
    }

    if (isPlaying) {
      pauseTimeRef.current = (audioCtxRef.current?.currentTime || 0) - startTimeRef.current;
      stopPlayback();
      setIsPlaying(false);
    } else {
      playFrom(audioBuffer, pauseTimeRef.current % audioBuffer.duration);
    }
  };

  const playFrom = (buffer: AudioBuffer, offset: number) => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    
    const source = audioCtxRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioCtxRef.current.destination);
    
    startTimeRef.current = audioCtxRef.current.currentTime - offset;
    source.start(0, offset);
    sourceRef.current = source;
    setIsPlaying(true);

    source.onended = () => {
      if (Math.abs((audioCtxRef.current?.currentTime || 0) - (startTimeRef.current + buffer.duration)) < 0.2) {
        setIsPlaying(false);
        setProgress(duration);
        pauseTimeRef.current = 0;
        if (progressInterval.current) clearInterval(progressInterval.current);
      }
    };

    progressInterval.current = window.setInterval(() => {
      const current = (audioCtxRef.current?.currentTime || 0) - startTimeRef.current;
      setProgress(Math.min(current, duration));
    }, 100);
  };

  return (
    <div className="w-full max-w-md mx-auto bg-[#181818] rounded-2xl p-6 shadow-2xl border border-white/10 fade-in">
      <div className="flex items-center gap-4 mb-6">
        <div className="w-20 h-20 bg-gradient-to-br from-[#1DB954] to-[#121212] rounded-lg flex items-center justify-center shadow-lg overflow-hidden relative">
           <span className="text-4xl">🎧</span>
           {isLoading && <div className="absolute inset-0 bg-black/50 flex items-center justify-center"><div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div></div>}
        </div>
        <div className="flex flex-col text-left">
          <h4 className="text-white font-black text-lg truncate">Welcome to Harmonize</h4>
          <p className="text-gray-400 text-xs font-bold uppercase tracking-widest">Leadership Wrapped 2026</p>
        </div>
      </div>

      <div className="space-y-4">
        <p className="text-sm italic font-medium text-[#1DB954] text-center px-4 leading-snug h-16 flex items-center justify-center">
          {isLoading ? "Fetching your session..." : "“Welcome to Harmonize, your year in leadership remixed. You’ll see your top strengths and growth moments.”"}
        </p>

        <div className="space-y-2">
          <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
            <div className="bg-[#1DB954] h-full" style={{ width: `${(progress / duration) * 100}%` }}></div>
          </div>
          <div className="flex justify-between text-[10px] font-bold text-gray-500">
            <span>0:{Math.floor(progress).toString().padStart(2, '0')}</span>
            <span>0:12</span>
          </div>
        </div>

        <div className="flex items-center justify-center gap-8 py-2">
          <button className="text-gray-400 hover:text-white transition-colors"><Icons.SkipBack /></button>
          <button 
            onClick={togglePlayback}
            className="w-14 h-14 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 transition-transform"
          >
            {isPlaying ? <Icons.Pause /> : <Icons.Play />}
          </button>
          <button className="text-gray-400 hover:text-white transition-colors"><Icons.SkipForward /></button>
        </div>
      </div>
    </div>
  );
};

/**
 * ==========================================
 * MAIN APP SCREENS
 * ==========================================
 */

const IntroScreen: React.FC<{ onStart: () => void }> = ({ onStart }) => (
  <div className="fade-in min-h-[70vh] flex flex-col items-center justify-center text-center space-y-12 py-10">
    <div className="space-y-6">
      <div className="inline-block bg-white/5 border border-white/10 px-4 py-1.5 rounded-full mb-4">
        <p className="text-[10px] font-black uppercase tracking-[0.4em] text-[#1DB954]">Leadership Development Module 2026</p>
      </div>
      <h2 className="text-6xl md:text-9xl font-black tracking-tighter leading-[0.85] text-white italic uppercase">
        LEAD LIKE A <br/><span className="text-[#1DB954]">BANDLEADER.</span>
      </h2>
    </div>

    <WelcomePlayer />

    <div className="flex flex-col items-center pt-8">
      <button onClick={onStart} className="btn-spotify flex items-center gap-4 text-xl shadow-[0_0_50px_rgba(29,185,84,0.2)] px-20 py-8">
        ENTER THE STUDIO
        <Icons.ArrowRight />
      </button>
      <p className="mt-8 text-[10px] text-gray-600 font-bold uppercase tracking-widest">CREATED WITH AI BY ZOHA MINAL IMRAN • 2026</p>
    </div>
  </div>
);

const SquadScreen: React.FC<{ onNext: () => void, onBack: () => void }> = ({ onNext, onBack }) => (
  <div className="fade-in space-y-12">
    <div className="text-center space-y-4">
      <h2 className="text-5xl md:text-6xl font-black tracking-tighter italic uppercase text-white">YOUR <span className="text-[#1DB954]">SQUAD.</span></h2>
      <p className="text-xl text-gray-400 max-w-2xl mx-auto font-medium leading-relaxed">High-performing squads at Spotify operate like world-class bands.</p>
    </div>
    <div className="grid md:grid-cols-3 gap-8 pt-8">
      {BAND_MEMBERS.map((member) => (
        <div key={member.id} className="spotify-card flex flex-col items-center text-center group border border-white/5 hover:border-[#1DB954]/30 p-8">
          <div className="w-24 h-24 bg-[#121212] rounded-full flex items-center justify-center text-5xl mb-6 border border-white/5">{member.icon}</div>
          <h3 className="font-black text-2xl mb-1 text-white uppercase italic">{member.role}</h3>
          <p className="text-[10px] text-[#1DB954] font-black uppercase tracking-[0.3em] mb-6">{member.strength}</p>
          <div className="bg-black/40 rounded-2xl p-5 border border-white/5 w-full text-left">
            <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-2">Corporate Tension</p>
            <p className="text-sm text-gray-200 italic">"{member.clashPoint}"</p>
          </div>
        </div>
      ))}
    </div>
    <div className="flex flex-col items-center pt-10 gap-6">
      <button onClick={onNext} className="btn-spotify px-16 py-6 text-lg">START THE LAUNCH SESSION</button>
      <button onClick={onBack} className="text-gray-500 hover:text-white text-[10px] font-black uppercase tracking-[0.3em]">Back</button>
    </div>
  </div>
);

const SimulationScreen: React.FC<{ onComplete: (result: LeadershipInsight) => void, onBack: () => void }> = ({ onComplete, onBack }) => {
  const [loading, setLoading] = useState(false);
  const strategies = [
    { id: '1', title: 'The Agile Remix', approach: 'Collaborative test on small % of users.' },
    { id: '2', title: 'The Hard System Order', approach: 'Priority on uptime and stability.' },
    { id: '3', title: 'The Squad Unplugged', approach: 'Conflict resolution and emotional safety.' }
  ];

  const handlePick = async (approach: string) => {
    setLoading(true);
    const result = await analyzeLeadershipResponse(approach);
    onComplete(result);
  };

  return (
    <div className="fade-in space-y-10">
      <div className="bg-[#181818] rounded-3xl p-10 border border-white/5 shadow-2xl relative overflow-hidden">
        <h3 className="text-2xl font-black italic uppercase text-white mb-6">Crisis in the Studio</h3>
        <p className="text-lg text-gray-300 mb-10 leading-relaxed border-l-2 border-[#1DB954] pl-6">"Rollout in 48h. Engineering says the new AI DJ model is unstable. Product wants the 'hit' features now. How do you lead?"</p>
        <div className="grid md:grid-cols-3 gap-6">
          {strategies.map(s => (
            <button key={s.id} onClick={() => handlePick(s.approach)} disabled={loading} className="spotify-card text-left p-6 flex flex-col gap-4 border-2 border-transparent hover:border-[#1DB954]">
              <h4 className="text-xl font-black italic uppercase text-[#1DB954]">{s.title}</h4>
              <p className="text-sm text-gray-400">Decide your path as a bandleader.</p>
            </button>
          ))}
        </div>
        {loading && <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center z-50">
          <div className="w-10 h-10 border-4 border-[#1DB954] border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-xs font-black uppercase tracking-widest text-[#1DB954]">Analyzing Your Rhythm...</p>
        </div>}
      </div>
      <button onClick={onBack} className="text-gray-500 hover:text-white text-[10px] font-black uppercase tracking-[0.3em] block mx-auto">Back</button>
    </div>
  );
};

const AnalysisScreen: React.FC<{ insight: LeadershipInsight, onNext: () => void }> = ({ insight, onNext }) => (
  <div className="space-y-10 fade-in py-10">
    <div className="text-center space-y-4">
      <div className="inline-block bg-white/10 text-white px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.3em]">AI ANALYSIS COMPLETE</div>
      <h2 className="text-6xl md:text-8xl font-black tracking-tighter italic text-white uppercase">{insight.archetype}</h2>
      <div className="text-6xl font-black text-[#1DB954]">{insight.score}% Match</div>
    </div>
    <div className="grid md:grid-cols-2 gap-6">
      <div className="spotify-card p-10 border border-white/5">
        <h3 className="text-[#1DB954] font-black text-xs uppercase tracking-widest mb-6">Feedback</h3>
        <p className="text-2xl font-bold text-gray-100">{insight.feedback}</p>
      </div>
      <div className="spotify-card p-10 border border-white/5 bg-[#191414]">
        <h3 className="text-[#1DB954] font-black text-xs uppercase tracking-widest mb-6">Genre</h3>
        <p className="text-xl italic font-medium text-gray-400">"{insight.musicalStyle}"</p>
      </div>
    </div>
    <button onClick={onNext} className="btn-spotify block mx-auto text-xl px-16 py-6 uppercase">See Wrapped 2026</button>
  </div>
);

const WrappedScreen: React.FC<{ insight: LeadershipInsight, onNext: () => void }> = ({ insight, onNext }) => (
  <div className="relative min-h-[600px] flex flex-col items-center justify-center overflow-hidden rounded-[40px] wrapped-gradient p-12 text-center fade-in">
    <div className="relative z-10 space-y-12">
      <p className="text-black font-black uppercase tracking-[0.4em] text-sm">2026 Leadership Wrapped</p>
      <h2 className="text-7xl md:text-9xl font-black text-white tracking-tighter italic leading-none">THE MIX.</h2>
      <div className="space-y-6">
        <p className="text-white/90 font-bold text-2xl">Your leadership style is:</p>
        <div className="inline-block bg-white text-black px-12 py-5 rounded-full text-4xl md:text-6xl font-black -rotate-2 uppercase tracking-tighter">
          {insight.archetype}
        </div>
      </div>
      <button onClick={onNext} className="bg-black text-white px-14 py-5 rounded-full font-black text-xl hover:bg-white hover:text-black transition-colors uppercase">The B-Side</button>
    </div>
  </div>
);

const TeaserScreen: React.FC<{ onRestart: () => void }> = ({ onRestart }) => (
  <div className="space-y-12 fade-in py-10">
    <div className="text-center space-y-6">
      <div className="inline-block bg-[#1DB954] text-black text-xs font-bold px-3 py-1 rounded uppercase">TALENT ACQUISITION SPECIAL</div>
      <h2 className="text-6xl md:text-8xl font-black tracking-tight leading-none italic uppercase text-white">THE <span className="text-[#1DB954]">B-SIDE.</span></h2>
      <p className="text-2xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
        The experience you just had? Built with AI to demonstrate the same innovation I plan to bring to Spotify's L&D strategy in 2026.
      </p>
    </div>
    <div className="bg-[#1DB954] text-black p-12 rounded-3xl text-center space-y-6">
      <h3 className="text-4xl font-black tracking-tighter uppercase italic">Ready to play the full album?</h3>
      <a href="mailto:zoha_minal_imran@outlook.com" className="inline-block bg-black text-white px-12 py-5 rounded-full font-bold text-xl hover:scale-105 transition-transform no-underline">LET'S CONNECT</a>
      <button onClick={onRestart} className="block mx-auto text-black/60 hover:text-black text-[10px] font-black uppercase tracking-[0.3em] mt-6">Restart</button>
    </div>
    <div className="text-center pt-10"><p className="text-gray-600 font-medium text-sm uppercase tracking-widest">DEVELOPED BY ZOHA MINAL IMRAN • 2026</p></div>
  </div>
);

const LoadingTransition: React.FC = () => (
  <div className="flex flex-col items-center justify-center min-h-[400px] space-y-12 fade-in">
    <div className="flex items-end justify-center gap-1 h-32 w-64">
      {[...Array(10)].map((_, i) => (<div key={i} className="w-4 bg-[#1DB954] rounded-full animate-equalizer" style={{ animationDelay: `${i * 0.1}s`, height: '20%' }}></div>))}
    </div>
    <h3 className="text-4xl font-black italic uppercase tracking-tighter text-white animate-pulse">Flipping the Vinyl...</h3>
    <style>{`@keyframes equalizer { 0%, 100% { height: 20%; } 50% { height: 100%; } } .animate-equalizer { animation: equalizer 0.6s ease-in-out infinite; }`}</style>
  </div>
);

/**
 * ==========================================
 * MAIN APP CONTAINER
 * ==========================================
 */

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep>(AppStep.INTRO);
  const [insight, setInsight] = useState<LeadershipInsight | null>(null);
  
  useEffect(() => {
    if (step === AppStep.LOADING_BSIDE) {
      const timer = setTimeout(() => setStep(AppStep.TEASER), 3000);
      return () => clearTimeout(timer);
    }
  }, [step]);

  return (
    <div className="min-h-screen bg-[#121212] flex flex-col text-white relative">
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-5xl h-[500px] bg-[#1DB954] opacity-[0.05] blur-[150px]"></div>
      </div>

      <header className="relative z-50 px-8 py-6 flex justify-between items-center bg-black/40 backdrop-blur-md border-b border-white/5">
        <div className="flex items-center gap-2 group cursor-pointer" onClick={() => setStep(AppStep.INTRO)}>
          <svg viewBox="0 0 24 24" width="32" height="32" fill="#1DB954"><path d="M12 0C5.37 0 0 5.37 0 12s5.37 12 12 12 12-5.37 12-12S18.63 0 12 0zm5.5 17.33c-.22.33-.67.44-1 .22-2.77-1.7-6.25-2.08-10.33-1.14-.38.09-.77-.14-.86-.52-.09-.38.14-.77.52-.86 4.45-1.02 8.3-.57 11.45 1.36.33.22.44.67.22 1zm1.45-3.27c-.28.45-.87.59-1.32.3-3.17-1.94-8-2.52-11.75-1.39-.5.15-1.03-.13-1.18-.63-.15-.5.13-1.03.63-1.18 4.3-1.3 9.63-.64 13.29 1.6.45.28.59.87.3 1.32zm.12-3.41c-3.8-2.25-10.06-2.46-13.67-1.37-.58.18-1.2-.16-1.38-.74-.18-.58.16-1.2.74-1.38 4.15-1.26 11.08-1.01 15.44 1.57.53.31.7.99.39 1.52-.31.53-.99.7-1.52.39z"/></svg>
          <h1 className="text-xl font-black uppercase italic tracking-tighter">Harmonize <span className="text-gray-500 font-medium ml-1">| L&D Lead 2026</span></h1>
        </div>
        <nav className="hidden md:flex gap-6 items-center text-[10px] font-black uppercase tracking-widest text-gray-500">
          <button onClick={() => setStep(AppStep.INTRO)} className={`${step === AppStep.INTRO ? 'text-[#1DB954]' : ''}`}>01 Intro</button>
          <button onClick={() => setStep(AppStep.SQUAD)} className={`${step === AppStep.SQUAD ? 'text-[#1DB954]' : ''}`}>02 Squad</button>
          <button onClick={() => setStep(AppStep.SIMULATION)} className={`${step === AppStep.SIMULATION ? 'text-[#1DB954]' : ''}`}>03 Simulation</button>
        </nav>
      </header>

      <main className="flex-1 relative z-10 px-6 py-12 md:px-12 max-w-7xl mx-auto w-full">
        {step === AppStep.INTRO && <IntroScreen onStart={() => setStep(AppStep.SQUAD)} />}
        {step === AppStep.SQUAD && <SquadScreen onNext={() => setStep(AppStep.SIMULATION)} onBack={() => setStep(AppStep.INTRO)} />}
        {step === AppStep.SIMULATION && <SimulationScreen onComplete={(res) => { setInsight(res); setStep(AppStep.RESULT); }} onBack={() => setStep(AppStep.SQUAD)} />}
        {step === AppStep.RESULT && insight && <AnalysisScreen insight={insight} onNext={() => setStep(AppStep.WRAPPED)} />}
        {step === AppStep.WRAPPED && insight && <WrappedScreen insight={insight} onNext={() => setStep(AppStep.LOADING_BSIDE)} />}
        {step === AppStep.LOADING_BSIDE && <LoadingTransition />}
        {step === AppStep.TEASER && <TeaserScreen onRestart={() => { setInsight(null); setStep(AppStep.INTRO); }} />}
      </main>

      <footer className="relative z-10 py-10 px-8 border-t border-white/5 opacity-40 text-center">
        <p className="text-[10px] font-black uppercase tracking-widest">PERSONALIZED FOR THE SPOTIFY RECRUITMENT TEAM • 2026</p>
      </footer>
    </div>
  );
};

export default App;
