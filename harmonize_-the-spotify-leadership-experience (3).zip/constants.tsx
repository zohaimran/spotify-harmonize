
import React from 'react';
import { BandMember } from './types.ts';

export const SPOTIFY_GREEN = '#1DB954';
export const SPOTIFY_BLACK = '#191414';

// Added missing BACKGROUND_TRACK constant for the MusicPlayer component
export const BACKGROUND_TRACK = {
  title: "Leader's Rhythm",
  artist: "Spotify L&D Mix",
  albumArt: "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=300&auto=format&fit=crop"
};

export const BAND_MEMBERS: BandMember[] = [
  {
    id: '1',
    role: 'Product Frontman',
    personality: 'Visionary, High-energy, data-obsessed but gut-driven',
    strength: 'User Impact & Vision',
    clashPoint: 'Pushes for "one more thing" before launch',
    icon: '🎤'
  },
  {
    id: '2',
    role: 'Infrastructure Maestro',
    personality: 'Pragmatic, Detail-oriented, focused on uptime and scalability',
    strength: 'Stability & System Harmony',
    clashPoint: 'Resistant to last-minute scope creep',
    icon: '🥁'
  },
  {
    id: '3',
    role: 'Growth Producer',
    personality: 'Strategic, analytical, bridge between tech and the listener',
    strength: 'Market Resonance',
    clashPoint: 'Prioritizes buzz over technical debt',
    icon: '🎚️'
  }
];

export const Icons = {
  Play: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="black">
      <path d="M7 6v12l10-6z" />
    </svg>
  ),
  Pause: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="black">
      <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
    </svg>
  ),
  Leader: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  ),
  ArrowRight: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <line x1="5" y1="12" x2="19" y2="12"></line>
      <polyline points="12 5 19 12 12 19"></polyline>
    </svg>
  )
};
