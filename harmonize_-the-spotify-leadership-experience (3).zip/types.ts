export interface BandMember {
  id: string;
  role: string;
  personality: string;
  strength: string;
  clashPoint: string;
  icon: string;
}

export interface LeadershipInsight {
  score: number;
  archetype: string;
  feedback: string;
  actionableAdvice: string;
  musicalStyle: string;
}

export enum AppStep {
  INTRO = 'INTRO',
  SQUAD = 'SQUAD',
  SIMULATION = 'SIMULATION',
  RESULT = 'RESULT',
  WRAPPED = 'WRAPPED',
  LOADING_BSIDE = 'LOADING_BSIDE',
  TEASER = 'TEASER'
}