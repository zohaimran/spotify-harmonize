
import React from 'react';

const LoadingTransition: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[400px] space-y-12 fade-in">
      <div className="flex items-end justify-center gap-1 h-32 w-64">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => (
          <div
            key={i}
            className="w-4 bg-[#1DB954] rounded-full"
            style={{
              animation: `spotifyEqualizer ${0.5 + Math.random() * 0.5}s ease-in-out infinite alternate`,
              animationDelay: `${i * 0.1}s`,
              height: '20%'
            }}
          ></div>
        ))}
      </div>
      
      <div className="text-center space-y-4">
        <h3 className="text-4xl font-black italic uppercase tracking-tighter text-white animate-pulse">
          Loading B-Side...
        </h3>
        <p className="text-gray-500 font-bold uppercase tracking-[0.3em] text-xs">
          Flipping the vinyl for the Talent Team
        </p>
      </div>

      <style>{`
        @keyframes spotifyEqualizer {
          0% { height: 20%; }
          100% { height: 100%; }
        }
      `}</style>
    </div>
  );
};

export default LoadingTransition;
