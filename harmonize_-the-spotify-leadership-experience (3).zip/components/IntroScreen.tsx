
import React from 'react';
import { Icons } from '../constants.tsx';

interface IntroScreenProps {
  onStart: () => void;
}

const IntroScreen: React.FC<IntroScreenProps> = ({ onStart }) => {
  return (
    <div className="fade-in min-h-[60vh] flex flex-col items-center justify-center text-center space-y-12">
      <div className="space-y-6">
        <div className="inline-block bg-white/5 border border-white/10 px-4 py-1.5 rounded-full mb-4">
          <p className="text-[10px] font-black uppercase tracking-[0.4em] text-[#1DB954]">Leadership Development Module</p>
        </div>
        <h2 className="text-7xl md:text-9xl font-black tracking-tighter leading-[0.85] text-white italic uppercase">
          LEAD LIKE A <br/><span className="text-[#1DB954]">BANDLEADER.</span>
        </h2>
        <p className="text-2xl text-gray-400 max-w-2xl mx-auto leading-relaxed font-medium">
          In the world of Spotify, leaders don't just manage teams—they orchestrate talent to create hits. 
          Ready to find your leadership rhythm?
        </p>
      </div>

      <div className="flex flex-col items-center pt-8">
        <button 
          onClick={onStart} 
          className="btn-spotify flex items-center gap-4 text-xl shadow-[0_0_50px_rgba(29,185,84,0.2)] px-20 py-8"
        >
          START EXPERIENCE
          <Icons.ArrowRight />
        </button>
        <div className="mt-8 space-y-2">
          <p className="text-[10px] text-gray-600 font-bold uppercase tracking-widest">
            CREATED WITH AI BY ZOHA MINAL IMRAN
          </p>
          <p className="text-[8px] text-gray-700 font-bold uppercase tracking-[0.2em]">
            PROTOTYPE FOR SPOTIFY L&D LEAD CANDIDACY
          </p>
        </div>
      </div>
    </div>
  );
};

export default IntroScreen;
