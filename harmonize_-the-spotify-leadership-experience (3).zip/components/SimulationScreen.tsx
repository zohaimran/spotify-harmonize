
import React, { useState } from 'react';
import { analyzeLeadershipResponse } from '../services/geminiService.ts';
import { LeadershipInsight } from '../types.ts';

interface SimulationScreenProps {
  onComplete: (result: LeadershipInsight) => void;
  onBack: () => void;
}

interface Strategy {
  id: string;
  title: string;
  genre: string;
  description: string;
  approach: string;
}

const STRATEGIES: Strategy[] = [
  {
    id: 'collab',
    title: 'The Agile Remix',
    genre: 'Indie Fusion',
    description: 'Host an emergency sprint. Let the Product and Engineering leads build a hybrid rollout plan that tests the new model on a small % of users first.',
    approach: 'I would facilitate a collaborative session where the Product Manager and Lead Engineer build a canary release plan together, ensuring the "flashy" feature is tested in production without risking total system failure.'
  },
  {
    id: 'decisive',
    title: 'The Hard System Order',
    genre: 'Heavy Metal',
    description: 'The global rollout is in 48 hours. Side with Engineering to ensure uptime. We stick to the stable algorithm—innovation can wait for v2.',
    approach: 'I would prioritize operational stability and the team\'s prior hard work. I would tell the Product Lead that while the vision is great, we cannot risk a platform crash on launch day. We ship the stable version now and iterate in the next sprint.'
  },
  {
    id: 'empathetic',
    title: 'The Squad Unplugged',
    genre: 'Acoustic Soul',
    description: 'Take the squad leads for a 1:1. Address the friction and the pressure of the PR window. Focus on long-term team health over this single launch.',
    approach: 'I would focus on the psychological safety of the squad. I would listen to the Engineer\'s technical anxiety and the Product Lead\'s vision pressure, resolving the human conflict first to ensure the team doesn\'t burn out before the global expansion.'
  },
  {
    id: 'visionary',
    title: 'The Visionary Solo',
    genre: 'Avant-Garde Pop',
    description: 'Back the Product Lead\'s bold model swap. Bring in extra AI specialists from other squads to help Engineering stabilize it. We chase the breakthrough.',
    approach: 'I would back the boldest innovation even if it creates technical debt. I would provide the Infrastructure team with extra "session players" (specialized engineers) to mitigate the risk, ensuring we don\'t miss a chance to disrupt the listening experience.'
  }
];

const SimulationScreen: React.FC<SimulationScreenProps> = ({ onComplete, onBack }) => {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!selectedId) return;
    const selectedStrategy = STRATEGIES.find(s => s.id === selectedId);
    if (!selectedStrategy) return;

    setLoading(true);
    try {
      const result = await analyzeLeadershipResponse(selectedStrategy.approach);
      onComplete(result);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  };

  return (
    <div className="fade-in space-y-10">
      <div className="bg-[#181818] rounded-3xl p-8 md:p-10 border border-white/5 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-2 h-full bg-[#1DB954]"></div>
        
        <div className="flex items-center gap-5 mb-8">
          <div className="w-14 h-14 bg-[#1DB954] rounded-2xl flex items-center justify-center text-black">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" /></svg>
          </div>
          <div>
            <h3 className="text-2xl font-black italic uppercase text-white leading-none">The Launch Conflict</h3>
            <p className="text-[#1DB954] text-[10px] font-black tracking-[0.25em] uppercase mt-1">Direct the Squad's Final Mix</p>
          </div>
        </div>

        <p className="text-xl italic text-gray-300 mb-10 leading-relaxed font-medium border-l-2 border-white/10 pl-6">
          "A major AI DJ update is set to drop in 48 hours. Your <strong>Product Frontman</strong> wants to swap the core algorithm for a newer 'flashier' model. Your <strong>Infrastructure Maestro</strong> says it's an unverified risk that could break the app. <strong>How do you orchestrate the fix?</strong>"
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative">
          {STRATEGIES.map((strategy) => (
            <button
              key={strategy.id}
              onClick={() => setSelectedId(strategy.id)}
              disabled={loading}
              className={`text-left p-6 rounded-2xl border-2 transition-all duration-300 group relative overflow-hidden ${
                selectedId === strategy.id 
                ? 'bg-[#282828] border-[#1DB954] shadow-[0_0_30px_rgba(29,185,84,0.2)]' 
                : 'bg-[#121212] border-white/5 hover:border-white/20'
              }`}
            >
              <div className="flex justify-between items-start mb-2">
                <span className={`text-[10px] font-black uppercase tracking-widest ${selectedId === strategy.id ? 'text-[#1DB954]' : 'text-gray-500'}`}>
                  {strategy.genre}
                </span>
                {selectedId === strategy.id && (
                  <div className="bg-[#1DB954] text-black rounded-full p-1 scale-110">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                  </div>
                )}
              </div>
              <h4 className="text-xl font-black italic uppercase mb-2 group-hover:text-[#1DB954] transition-colors">{strategy.title}</h4>
              <p className="text-sm text-gray-400 leading-snug">{strategy.description}</p>
              
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-[#1DB954] opacity-0 group-hover:opacity-5 blur-3xl transition-opacity"></div>
            </button>
          ))}

          {loading && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm rounded-2xl z-20 flex flex-col items-center justify-center space-y-4">
              <div className="w-12 h-12 border-4 border-[#1DB954]/20 border-t-[#1DB954] rounded-full animate-spin"></div>
              <p className="text-xs font-black uppercase tracking-widest text-[#1DB954]">Synthesizing Product Harmony...</p>
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-col md:flex-row justify-between items-center gap-6">
        <button 
          onClick={onBack}
          className="text-gray-500 hover:text-white text-[10px] font-black uppercase tracking-[0.3em] transition-colors"
        >
          Back to Squad
        </button>
        <div className="flex flex-col md:flex-row items-center gap-6 w-full md:w-auto">
          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest text-center md:text-right">
            {!selectedId ? 'Choose a leadership style' : 'Ready to analyze'}
          </p>
          <button 
            onClick={handleSubmit}
            disabled={loading || !selectedId}
            className={`btn-spotify flex items-center gap-3 w-full md:w-auto justify-center ${loading || !selectedId ? 'opacity-30 cursor-not-allowed grayscale' : ''}`}
          >
            {loading ? 'Analyzing...' : 'Confirm Launch Strategy'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SimulationScreen;
