
import React from 'react';
import { LeadershipInsight } from '../types.ts';

interface WrappedScreenProps {
  insight: LeadershipInsight;
  onNext: () => void;
}

const WrappedScreen: React.FC<WrappedScreenProps> = ({ insight, onNext }) => {
  return (
    <div className="relative min-h-[650px] flex flex-col items-center justify-center overflow-hidden rounded-[40px] wrapped-gradient p-12 text-center fade-in">
      {/* Decorative Blur Elements */}
      <div className="absolute top-[-20%] left-[-20%] w-[500px] h-[500px] bg-[#ff4132] rounded-full blur-[120px] opacity-40 animate-[pulseSlow_6s_infinite]"></div>
      <div className="absolute bottom-[-20%] right-[-20%] w-[600px] h-[600px] bg-[#503750] rounded-full blur-[150px] opacity-60 animate-[pulseSlow_8s_infinite]"></div>
      
      <div className="relative z-10 space-y-12">
        <div className="space-y-4">
          <p className="text-black font-black uppercase tracking-[0.4em] text-sm">2026 Leadership Wrapped</p>
          <h2 className="text-7xl md:text-9xl font-black text-white tracking-tighter italic leading-none">THE MIX.</h2>
        </div>

        <div className="space-y-6">
          <p className="text-white/90 font-bold text-2xl tracking-tight">Your leadership style is:</p>
          <div className="inline-block bg-white text-black px-12 py-5 rounded-full text-4xl md:text-5xl font-black -rotate-3 shadow-2xl uppercase tracking-tighter">
            {insight.archetype}
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-10 md:gap-20 pt-8">
          <div className="space-y-1 text-center">
            <div className="text-5xl md:text-6xl font-black text-white leading-none">{insight.score}</div>
            <div className="text-[10px] font-black text-white/50 uppercase tracking-[0.2em]">Harmony Score</div>
          </div>
          <div className="space-y-1 border-x border-white/20 px-10 md:px-20 text-center">
            <div className="text-5xl md:text-6xl font-black text-white leading-none">TOP 0.5%</div>
            <div className="text-[10px] font-black text-white/50 uppercase tracking-[0.2em]">Global Growth Mindset</div>
          </div>
          <div className="space-y-1 text-center">
            <div className="text-5xl md:text-6xl font-black text-white leading-none">100%</div>
            <div className="text-[10px] font-black text-white/50 uppercase tracking-[0.2em]">Culture Fit</div>
          </div>
        </div>

        <div className="pt-10">
          <button 
            onClick={onNext}
            className="bg-black text-white px-14 py-5 rounded-full font-black text-xl hover:bg-white hover:text-black transition-colors shadow-2xl uppercase tracking-tight border-none cursor-pointer"
          >
            Go to the B-Side
          </button>
        </div>
      </div>
    </div>
  );
};

export default WrappedScreen;
