
import React from 'react';
import { BAND_MEMBERS } from '../constants.tsx';

interface SquadScreenProps {
  onNext: () => void;
  onBack: () => void;
}

const SquadScreen: React.FC<SquadScreenProps> = ({ onNext, onBack }) => {
  return (
    <div className="fade-in space-y-12">
      <div className="text-center space-y-4">
        <h2 className="text-5xl md:text-6xl font-black tracking-tighter italic uppercase text-white">
          YOUR <span className="text-[#1DB954]">SQUAD.</span>
        </h2>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto font-medium leading-relaxed">
          At Spotify, high-performing squads operate like world-class bands. You lead the group, but these are the specialists who make the music happen.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 pt-8">
        {BAND_MEMBERS.map((member) => (
          <div key={member.id} className="spotify-card flex flex-col items-center text-center group border border-white/5 hover:border-[#1DB954]/30 relative overflow-hidden p-8">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-30 transition-opacity">
              <span className="text-5xl font-black italic">0{member.id}</span>
            </div>
            <div className="w-24 h-24 bg-[#121212] rounded-full flex items-center justify-center text-5xl mb-6 shadow-inner group-hover:scale-110 transition-transform duration-500 border border-white/5">
              {member.icon}
            </div>
            <h3 className="font-black text-2xl mb-1 text-white uppercase italic">{member.role}</h3>
            <p className="text-[10px] text-[#1DB954] font-black uppercase tracking-[0.3em] mb-6">{member.strength}</p>
            
            <div className="space-y-4 w-full text-left">
              <div className="bg-black/40 rounded-2xl p-5 border border-white/5">
                <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-2">Corporate Tension</p>
                <p className="text-sm text-gray-200 italic leading-relaxed">"{member.clashPoint}"</p>
              </div>
              <p className="text-xs text-gray-500 font-medium leading-relaxed px-2">
                {member.personality}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-col items-center pt-10 gap-6">
        <button 
          onClick={onNext} 
          className="btn-spotify px-16 py-6 text-lg"
        >
          START THE LAUNCH SESSION
        </button>
        <button 
          onClick={onBack}
          className="text-gray-500 hover:text-white text-[10px] font-black uppercase tracking-[0.3em] transition-colors"
        >
          Go Back to Intro
        </button>
      </div>
    </div>
  );
};

export default SquadScreen;
