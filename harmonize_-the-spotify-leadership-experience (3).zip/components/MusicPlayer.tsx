
import React from 'react';
import { BACKGROUND_TRACK, Icons } from '../constants.tsx';

interface MusicPlayerProps {
  isPlaying: boolean;
  onToggle: () => void;
}

const MusicPlayer: React.FC<MusicPlayerProps> = ({ isPlaying, onToggle }) => {
  return (
    <div className="fixed bottom-8 left-8 z-[100] flex items-center gap-4 bg-black/90 backdrop-blur-3xl p-3 pl-4 pr-6 rounded-full border border-white/10 shadow-[0_25px_50px_-12px_rgba(0,0,0,0.8)] fade-in group transition-all hover:scale-105 hover:bg-[#121212] border-l-[#1DB954] border-l-2">
      <div className="relative">
        <img 
          src={BACKGROUND_TRACK.albumArt} 
          alt="Album Art" 
          className={`w-12 h-12 rounded-lg shadow-lg transition-all duration-1000 ${isPlaying ? 'animate-[spin_8s_linear_infinite]' : 'rotate-0'}`}
          style={{ borderRadius: isPlaying ? '50%' : '8px' }}
        />
        {isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-3 h-3 bg-black rounded-full border border-white/20 shadow-inner"></div>
          </div>
        )}
      </div>
      
      <div className="flex flex-col min-w-[100px]">
        <span className="text-white text-xs font-black uppercase tracking-tight leading-none mb-1 group-hover:text-[#1DB954] transition-colors">
          {BACKGROUND_TRACK.title}
        </span>
        <span className="text-gray-500 text-[9px] font-bold uppercase tracking-widest">
          {BACKGROUND_TRACK.artist}
        </span>
      </div>

      <div className="ml-2 flex items-center justify-center">
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onToggle();
          }}
          className="w-10 h-10 bg-[#1DB954] rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(29,185,84,0.4)] hover:scale-110 active:scale-95 transition-all group-hover:bg-[#1ed760]"
          aria-label={isPlaying ? "Pause Music" : "Play Music"}
        >
          {isPlaying ? <Icons.Pause /> : <Icons.Play />}
        </button>
      </div>

      {/* Spotify-style bars */}
      <div className="flex items-end gap-[3px] h-3 ml-2 w-6 overflow-hidden">
        {[1, 2, 3, 4].map(i => (
          <div 
            key={i} 
            className={`w-[2.5px] bg-[#1DB954] rounded-full transition-all duration-300 ${isPlaying ? 'animate-[equalizer_0.5s_ease-in-out_infinite_alternate]' : 'h-[2px] opacity-20'}`}
            style={{ 
              animationDelay: `${i * 0.12}s`,
              height: isPlaying ? 'auto' : '2px'
            }}
          ></div>
        ))}
      </div>

      <style>{`
        @keyframes equalizer {
          from { height: 2px; }
          to { height: 16px; }
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default MusicPlayer;
