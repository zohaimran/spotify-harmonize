
import React from 'react';

interface TeaserScreenProps {
  onRestart: () => void;
}

const TeaserScreen: React.FC<TeaserScreenProps> = ({ onRestart }) => {
  return (
    <div className="space-y-12 fade-in">
      <div className="text-center space-y-6">
        <div className="inline-block bg-[#1DB954] text-black text-xs font-bold px-3 py-1 rounded uppercase mb-4">FOR SPOTIFY TALENT ACQUISITION</div>
        <h2 className="text-6xl md:text-8xl font-black tracking-tight leading-none italic uppercase text-white">
          This is just the <br/><span className="text-[#1DB954]">B-Side.</span>
        </h2>
        <p className="text-2xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
          The experience you just had? It was built with AI to demonstrate the same agility and innovation I plan to bring to Spotify's Learning & Development strategy.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="spotify-card p-10 flex flex-col justify-center space-y-4 border border-white/5">
          <h3 className="text-2xl font-bold text-[#1DB954]">The "Next Era" Vision</h3>
          <p className="text-gray-400 leading-relaxed">
            As your L&D Lead, I won't just buy off-the-shelf courses. I will build high-fidelity, interactive, AI-driven learning ecosystems that adapt to Spotify's unique culture and the specific needs of our 'bands' (squads).
          </p>
        </div>
        <div className="spotify-card p-10 flex flex-col justify-center space-y-4 border border-white/5">
          <h3 className="text-2xl font-bold text-[#1DB954]">AI x Human Experience</h3>
          <p className="text-gray-400 leading-relaxed">
            I understand how to weave AI into the human experience. From personalized coaching at scale to dynamic leadership simulations, I turn learning into a 'can't-stop-listening' experience.
          </p>
        </div>
      </div>

      <div className="bg-[#1DB954] text-black p-12 rounded-3xl text-center space-y-6">
        <h3 className="text-4xl font-black tracking-tighter uppercase italic">Ready to play the full album?</h3>
        <p className="text-xl font-medium max-w-2xl mx-auto opacity-80">
          I'm ready to transform how Spotify learns using the full potential of AI. Let's talk about the future of talent development.
        </p>
        <div className="pt-4 flex flex-col items-center gap-6">
          <a 
            href="mailto:zoha_minal_imran@outlook.com" 
            className="inline-block bg-black text-white px-12 py-5 rounded-full font-bold text-xl hover:scale-105 transition-transform decoration-none"
          >
            LET'S CONNECT
          </a>
          <button 
            onClick={onRestart}
            className="text-black/60 hover:text-black text-[10px] font-black uppercase tracking-[0.3em] transition-colors"
          >
            Restart Experience
          </button>
        </div>
      </div>

      <div className="text-center space-y-2">
        <p className="text-gray-600 font-medium text-sm uppercase tracking-widest">
          DEVELOPED WITH AI BY ZOHA MINAL IMRAN • 2026
        </p>
        <p className="text-[10px] text-gray-700 font-bold uppercase tracking-[0.2em]">
          PERSONALIZED FOR THE SPOTIFY RECRUITMENT TEAM
        </p>
      </div>
    </div>
  );
};

export default TeaserScreen;
