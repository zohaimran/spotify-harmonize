
import React from 'react';
import { LeadershipInsight } from '../types.ts';

interface AnalysisScreenProps {
  insight: LeadershipInsight;
  onNext: () => void;
}

const AnalysisScreen: React.FC<AnalysisScreenProps> = ({ insight, onNext }) => {
  return (
    <div className="space-y-10 fade-in">
      <div className="text-center space-y-4">
        <div className="inline-block bg-white/10 text-white px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.3em] border border-white/10">
          AI LEADERSHIP MIX
        </div>
        <h2 className="text-6xl md:text-7xl font-black tracking-tighter italic text-white">{insight.archetype}</h2>
        <div className="flex flex-col items-center">
            <div className="text-6xl font-black text-[#1DB954]">{insight.score}%</div>
            <div className="text-xs font-bold text-gray-500 uppercase tracking-widest">Coordination Level</div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="spotify-card p-10 border border-white/5 flex flex-col justify-center">
          <h3 className="text-[#1DB954] font-black text-xs uppercase tracking-widest mb-6">The Feedback Loop</h3>
          <p className="text-2xl leading-tight font-bold text-gray-100">
            {insight.feedback}
          </p>
        </div>
        <div className="spotify-card p-10 border border-white/5 flex flex-col justify-center bg-[#191414]">
          <h3 className="text-[#1DB954] font-black text-xs uppercase tracking-widest mb-6">The Liner Note</h3>
          <p className="text-xl italic font-medium text-gray-400 leading-relaxed">
            "{insight.musicalStyle}"
          </p>
        </div>
      </div>

      <div className="bg-gradient-to-br from-[#1DB954]/20 to-black/40 p-10 rounded-3xl border border-[#1DB954]/30">
        <h3 className="font-black text-sm uppercase tracking-widest mb-4 flex items-center gap-3 text-white">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1DB954" strokeWidth="2.5">
            <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
          </svg>
          Mastering Your Move
        </h3>
        <p className="text-gray-300 text-xl font-medium leading-relaxed">{insight.actionableAdvice}</p>
      </div>

      <div className="flex justify-center pt-6">
        <button 
          onClick={onNext}
          className="btn-spotify text-xl px-16 py-6"
        >
          SEE MY WRAPPED 2026
        </button>
      </div>
    </div>
  );
};

export default AnalysisScreen;
