
import { GoogleGenAI, Type } from "@google/genai";
import { LeadershipInsight } from "../types.ts";

export const analyzeLeadershipResponse = async (userInput: string): Promise<LeadershipInsight> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Role: Senior Leadership Coach at Spotify.
    Scenario: The "Bandleader" (Manager) has chosen a specific approach to resolve a crisis between a Lead Singer (PM) and a Drummer (Engineering).
    Chosen Approach: "${userInput}"
    
    Task: Analyze this decision through the lens of Spotify's values: Courage, Passion, Collaboration, Innovation, and Playfulness. 
    Explain why this approach works (or the trade-offs it makes) in a music-industry context.
    
    Return a JSON response with this exact structure:
    {
      "score": number (0-100 reflecting leadership effectiveness),
      "archetype": "string (A creative music-themed leadership title like 'The Master Mixer', 'The Hard Rock CEO', 'The Indie Spirit')",
      "feedback": "string (1-2 sentences of coaching feedback analyzing the choice)",
      "actionableAdvice": "string (One specific tip to enhance this style of leadership at Spotify)",
      "musicalStyle": "string (A genre or musical metaphor that fits the chosen strategy)"
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            archetype: { type: Type.STRING },
            feedback: { type: Type.STRING },
            actionableAdvice: { type: Type.STRING },
            musicalStyle: { type: Type.STRING }
          },
          required: ["score", "archetype", "feedback", "actionableAdvice", "musicalStyle"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from Gemini");
    
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return {
      score: 85,
      archetype: "The Harmony Orchestrator",
      feedback: "You demonstrated exceptional balance between creative vision and operational stability.",
      actionableAdvice: "Consider giving the 'Drummer' (Engineering) more visibility early in the composition phase.",
      musicalStyle: "Electronic Fusion"
    };
  }
};
